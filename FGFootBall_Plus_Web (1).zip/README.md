# FGFootBall Plus 1.1

Esta carpeta es la edición web estática. Para probarla, sirve la carpeta por HTTP en `localhost`; para usar el perfil y las notificaciones en un sitio remoto, utiliza HTTPS. La página de entrada es `index.html`.

## Datos y perfiles

- Los resultados, las clasificaciones y las fichas consultan a ESPN. Un guion indica un dato no publicado; no significa cero. La media se calcula como goles divididos por partidos disputados.
- Las cuentas, fotos de perfil, favoritos, avisos, alineaciones y rumores añadidos se guardan en este navegador o en el entorno privado de la APK. No se sincronizan.
- Se pueden compartir rumores como enlaces en la web y como texto en Android. La traducción automática depende de la API de traducción en el navegador; si no está disponible se conserva el original.
- Los avisos de goles se generan mientras la app está abierta. Los avisos del sistema requieren activarlos en Ajustes y conceder el permiso correspondiente.
- El paquete Android `app.fgfootball.plus` es independiente de `app.fgfootball.android`. El navegador y la APK utilizan los mismos archivos web.
